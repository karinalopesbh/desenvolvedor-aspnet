﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace BancoDados
{
    public class BancoDados
    {
        private SqlConnection ConexaoSql; // Conexão Sql
        private string StrConexao; // String de Conexão

        public BancoDados()
        {
            Conectar();
        }

        private void Conectar()
        {
            StrConexao = PegarString();
            ConexaoSql = PegarConexaoSql();
        }

        private string PegarString()
        {
            string banco = "PlanB";
            string servidor = "KARINAALVES";
            string login = "sa";
            string senha = "123456";

            // Monta string de conexão
            StrConexao =string.Format(@"Data Source={0};
                                        Initial Catalog={1};
                                        User ID={2};
                                        password={3};", servidor, banco, login, senha);

            return StrConexao;
        }

        public SqlConnection PegarConexaoSql() // Metódo que retorna um SqlConnection
        {
            ConexaoSql = new SqlConnection(StrConexao); // Criar Conexão com BD
            return ConexaoSql;
        }

        public DataTable ConsultaSQL(string query) // Metódo que retorna uma DataTable a partir da Query
        {
            DataTable dtbPesq = new DataTable(); // Cria um DataTabale
            SqlCommand sqlcomando = new SqlCommand();
            SqlDataAdapter sda = new SqlDataAdapter();

            try
            {
                ConexaoSql.Open(); // Abre a conexão
                sqlcomando.CommandText = query;
                sqlcomando.Connection = ConexaoSql;
                sda.SelectCommand = sqlcomando;
                sda.Fill(dtbPesq); // Preenche o DataTable
                ConexaoSql.Close(); // Fecha Conexão

                return dtbPesq; // Retorna DataTable
            }
            catch (Exception e)
            {
                ConexaoSql.Close(); // Fechar conexão
                throw e;
            }
        }

        public string NovaChavePrimaria(string chaveprimaria, string tabela)
        {
            int novachave = 0;
            string sql = string.Empty;
            DataTable dtbPesq = new DataTable();

            sql = "select isnull( max( " + chaveprimaria + " ) , 0 ) as " + chaveprimaria + " " +
                  "from " + tabela;

            dtbPesq = ConsultaSQL(sql);

            if (dtbPesq.Rows.Count == 1)
            {
                novachave = Convert.ToInt32(dtbPesq.Rows[0][chaveprimaria]);
                novachave += 1;
            }

            return novachave.ToString();
        }

        public bool ExecutarQuery(string query)
        {
            SqlCommand sqlcomando = new SqlCommand();
            SqlConnection SqlConexao = PegarConexaoSql();

            try
            {
                sqlcomando.CommandText = query;
                sqlcomando.Connection = ConexaoSql;
                SqlConexao.Open();
                sqlcomando.ExecuteNonQuery();
                SqlConexao.Close();
                return true;
            }
            catch (Exception)
            {
                ConexaoSql.Close(); // Fechar conexão
                return false;
            }
        }

        public Object VerificarStringNula(string valor)
        {
            if (valor == null || valor == string.Empty)
            {
                return DBNull.Value;
            }
            else
            {
                return valor;
            }
        }

    }
}
