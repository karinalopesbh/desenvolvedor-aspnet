begin tran
insert into TbUsuarios values (0, 0, 'Administrador', 'Administrador', null, null, '5cjOxr/qKfd02TDQjVrSIA==', GETDATE())
--commit
--rollback