begin tran
insert into TbTipoUsuario values(0, 'Administrador', GETDATE())
go
insert into TbTipoUsuario values(1, 'Programador', GETDATE())
go
insert into TbTipoUsuario values(2, 'Designer', GETDATE())
go
--commit
--rollback