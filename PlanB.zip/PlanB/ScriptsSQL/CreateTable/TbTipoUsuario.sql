create table TbTipoUsuario
(
	IdTipo int not null, 
	Nome varchar(30),
	DataCriacao datetime,
	constraint pk_IdTipo primary key( IdTipo ),
)