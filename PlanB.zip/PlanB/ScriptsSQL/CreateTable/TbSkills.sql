create table TbSkills
(
	IdSkill int not null, 
	Nome varchar(30),
	DataCriacao datetime,
	constraint pk_IdSkill primary key( IdSkill ),
)