create table TbUsuarios
(
	IdUsuario int not null, 
	TipoUsuario int not null,
	Nome varchar(30),
	Login varchar(30),
	Telefone varchar(30),
	Email varchar(100),
	Senha varchar(30),	
	DataCriacao datetime,
	constraint pk_IdUsuario primary key( IdUsuario ),
	constraint fk_TipoUsuario foreign key( TipoUsuario ) references TbTipoUsuario( IdTipo ),
)