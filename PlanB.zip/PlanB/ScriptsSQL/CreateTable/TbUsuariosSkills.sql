create table TbUsuariosSkills
(
	IdUsuariosSkills int not null, -- pk
	IdUsuario int not null, -- fk
	IdSkill int not null, -- fk
	DataCriacao datetime,
	constraint pk_IdUsuariosSkills primary key( IdUsuariosSkills ),
	constraint fk_IdUsuario foreign key( IdUsuario ) references TbUsuarios( IdUsuario ),
	constraint fk_IdSkill foreign key( IdSkill ) references TbSkills( IdSkill )
)
