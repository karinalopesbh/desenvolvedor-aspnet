﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace PlanB.Models
{
    public class Usuarios
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();
        BancoDados.Criptografia crip = new BancoDados.Criptografia();

        string sql = string.Empty;

        public int IdUsuario { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        [StringLength(30, MinimumLength = 1)]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo Login é obrigatório.")]
        [StringLength(30, MinimumLength = 1)]
        public string Login { get; set; }

        [Required(ErrorMessage = "O campo Senha é obrigatório.")]
        [StringLength(10, MinimumLength = 1)]
        public string Senha { get; set; }

        public string Telefone { get; set; }
        public string Email { get; set; }
        public string TipoUsuario { get; set; }
        public string NomeTipoUsuario { get; set; }

        public System.Web.Mvc.SelectList ListaTipos;

        public bool CriarUsuario()
        {
            string chave = bd.NovaChavePrimaria("IdUsuario", "TbUsuarios");

            sql = string.Format(@"insert into TbUsuarios values ({0}, {1}, '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')",
                                chave, Convert.ToInt32(TipoUsuario), Nome, Login, bd.VerificarStringNula(Telefone), bd.VerificarStringNula(Email),
                                crip.CriptografarTexto(Senha), DateTime.Now);

            return bd.ExecutarQuery(sql);
        }

        public bool ExisteUsuario(bool Inserir)
        {
            DataTable dt = new DataTable();

            if (Inserir)
            {
                sql = string.Format(@"select IdUsuario
                                from TbUsuarios
                                where lower(Login) = '{0}'", Login.ToLower());
            }
            else
            {
                sql = string.Format(@"select IdUsuario
                                from TbUsuarios
                                where lower(Login) = '{0}'
                                and IdUsuario <> {1}", Login.ToLower(), IdUsuario);
            }

            dt = bd.ConsultaSQL(sql);

            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Usuarios GetUsuario(int Id)
        {
            DataTable dt = new DataTable();

            sql = string.Format(@"select IdUsuario, TipoUsuario, Nome, Login, Telefone, Email
                                from TbUsuarios
                                where IdUsuario = {0}", Id);
            dt = bd.ConsultaSQL(sql);

            Usuarios usr = new Usuarios();
            usr.IdUsuario = Id;
            usr.TipoUsuario = dt.Rows[0]["TipoUsuario"].ToString();
            usr.Nome = dt.Rows[0]["Nome"].ToString();
            usr.Login = dt.Rows[0]["Login"].ToString();
            usr.Telefone = dt.Rows[0]["Telefone"].ToString();
            usr.Email = dt.Rows[0]["Email"].ToString();

            return usr;
        }

        public bool EditaUsuario()
        {
            sql = string.Format(@"update TbUsuarios
                                set TipoUsuario = {0},
                                Nome = '{1}',
                                Login = '{2}',
                                Telefone = '{3}',
                                Email = '{4}',
                                Senha = '{5}'
                                where IdUsuario = {6}",
                                Convert.ToInt32(TipoUsuario), Nome, Login, 
                                bd.VerificarStringNula(Telefone), 
                                bd.VerificarStringNula(Email), 
                                crip.CriptografarTexto(Senha), IdUsuario);

            return bd.ExecutarQuery(sql);
        }

        public Usuarios ExcluirUsuario(int Id)
        {
            sql = string.Format(@"delete from TbUsuarios
                                  where IdUsuario = {0}", Id);
            bd.ExecutarQuery(sql);

            return new Usuarios();
        }
    }

    public class UsuariosObject
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();
        string sql = string.Empty;

        public List<Usuarios> ListaUsuarios()
        {
            List<Usuarios> lusr = new List<Usuarios>();

            DataTable dt = new DataTable();

            sql = @"select IdUsuario, TipoUsuario, TbTipoUsuario.Nome NomeTipoUsuario, TbUsuarios.Nome, Login, Telefone, Email
                  from TbUsuarios
                  inner join TbTipoUsuario
                  on TbTipoUsuario.IdTipo = TbUsuarios.TipoUsuario";

            dt = bd.ConsultaSQL(sql);

            foreach (DataRow dr in dt.Rows)
            {
                Usuarios usr = new Usuarios();
                usr.IdUsuario = Convert.ToInt32(dr["IdUsuario"]);
                usr.Nome = dr["Nome"].ToString();
                usr.Login = dr["Login"].ToString();
                usr.TipoUsuario = dr["TipoUsuario"].ToString();
                usr.NomeTipoUsuario = dr["NomeTipoUsuario"].ToString();
                usr.Telefone = dr["Telefone"].ToString();
                usr.Email = dr["Email"].ToString();

                lusr.Add(usr);
            }

            return lusr;
        }
    }

    public class TipoUsuario
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();
        string sql = string.Empty;

        public int IdTipo { get; set; }
        public string Nome { get; set; }

        public List<TipoUsuario> ListaTipoUsuario()
        {
            List<TipoUsuario> ltpu = new List<TipoUsuario>();

            DataTable dt = new DataTable();

            sql = @"select IdTipo, Nome
                  from TbTipoUsuario ";

            dt = bd.ConsultaSQL(sql);

            foreach (DataRow dr in dt.Rows)
            {
                TipoUsuario tpu = new TipoUsuario();
                tpu.IdTipo = Convert.ToInt32(dr["IdTipo"]);
                tpu.Nome = dr["Nome"].ToString();
                ltpu.Add(tpu);
            }

            return ltpu;
        }
    }
}