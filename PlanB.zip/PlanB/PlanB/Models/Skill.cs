﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace PlanB.Models
{
    public class Skill
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();

        string sql = string.Empty;

        public int IdSkill { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        [StringLength(30, MinimumLength = 1)]
        public string Nome { get; set; }

        public bool Selecionado { get; set; }

        public bool ExisteSkill()
        {
            DataTable dt = new DataTable();

            sql = string.Format(@"select IdSkill
                                from TbSkills
                                where lower(Nome) = '{0}'", Nome.ToLower());
            dt = bd.ConsultaSQL(sql);

            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CriaSkill()
        {
            string chave = bd.NovaChavePrimaria("IdSkill", "TbSkills");

            sql = string.Format(@"insert into TbSkills values ({0}, '{1}', '{2}')",
                                chave, Nome, DateTime.Now);

            return bd.ExecutarQuery(sql);
        }

        public bool EditaSkill()
        {
            sql = string.Format(@"update TbSkills 
                                set Nome = '{0}'
                                where IdSkill = {1}",
                                Nome, IdSkill);

            return bd.ExecutarQuery(sql);
        }

        public Skill GetSkill(int Id)
        {
            DataTable dt = new DataTable();

            sql = string.Format(@"select IdSkill, Nome
                                from TbSkills
                                where IdSkill = {0}", Id);
            dt = bd.ConsultaSQL(sql);

            Skill sk = new Skill();
            sk.IdSkill = Id;
            sk.Nome = dt.Rows[0]["Nome"].ToString();

            return sk;
        }

        public Skill ExcluirSkill(int Id)
        {
            sql = string.Format(@"delete from TbSkills
                                  where IdSkill = {0}", Id);
            bd.ExecutarQuery(sql);

            return new Skill();
        }
    }

    public class SkillsObject
    {
        BancoDados.BancoDados bd = new BancoDados.BancoDados();
        string sql = string.Empty;

        public List<Skill> ListaSkills()
        {
            List<Skill> ls = new List<Skill>();

            DataTable dt = new DataTable();

            sql = @"select IdSkill, Nome
                  from TbSkills";

            dt = bd.ConsultaSQL(sql);

            foreach (DataRow dr in dt.Rows)
            {
                Skill s = new Skill();
                s.IdSkill = Convert.ToInt32(dr["IdSkill"]);
                s.Nome = dr["Nome"].ToString();
                ls.Add(s);
            }

            return ls;
        }
    }
}