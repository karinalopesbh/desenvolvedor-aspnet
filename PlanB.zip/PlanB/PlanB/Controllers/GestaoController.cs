﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PlanB.Models;

namespace PlanB.Controllers
{
    public class GestaoController : Controller
    {
        //Login
        public ActionResult Login()
        {
            return View();
        }
                
        [HttpPost]
        public ActionResult Login(Login model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                //Verifica se o usuário é válido
                if (model.UsuarioValido())
                {
                    //Verifica se é o Administrador
                    if(model.UsuarioAdministrador())
                    {
                        return Redirect("/Gestao/Usuarios");
                    }
                    else
                    {
                        return Redirect("/Gestao/Principal");
                    }                    
                }
                else
                {
                    ModelState.AddModelError("", "Usuário ou senha inválidos");
                    return View(model);
                }
            }
        }

        //Tela principal para quem não é Administrador
        public ActionResult Principal()
        {
            return View();
        }

        //Usuários
        public ActionResult Usuarios()
        {
            UsuariosObject usr = new UsuariosObject();
            var model = usr.ListaUsuarios();
            return View(model);
        }

        //Novo
        public ActionResult NovoUsuario()
        {
            ViewBag.TipoUsuarioId = new SelectList(
                new TipoUsuario().ListaTipoUsuario(),
                "IdTipo",
                "Nome"
                );

            ViewBag.ChkSkill = new SkillsObject().ListaSkills();

            return View();
        }

        [HttpPost]
        public ActionResult NovoUsuario(Usuarios model)
        {
            ViewBag.TipoUsuarioId = new SelectList(
                new TipoUsuario().ListaTipoUsuario(),
                "IdTipo",
                "Nome"
                );

            ViewBag.ChkSkill = new SkillsObject().ListaSkills();

            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                //Verifica se usuario ja existe
                if (!model.ExisteUsuario(true))
                {
                    if (model.CriarUsuario())
                    {
                        return Redirect("/Gestao/Usuarios");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Erro ao criar usuário");
                        return View(model);
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Já existe usuário com este login");
                    return View(model);
                }
            }
        }

        //Editar
        public ActionResult EditarUsuario(int id)
        {
            Usuarios usr = new Usuarios().GetUsuario(id);

            ViewBag.TipoUsuarioId = new SelectList(
                new TipoUsuario().ListaTipoUsuario(),
                "IdTipo",
                "Nome",
                usr.TipoUsuario
                );

            ViewBag.ChkSkill = new SkillsObject().ListaSkills();

            var model = usr;
            return View(model);
        }

        [HttpPost]
        public ActionResult EditarUsuario(Usuarios model)
        {
            ViewBag.TipoUsuarioId = new SelectList(
                new TipoUsuario().ListaTipoUsuario(),
                "IdTipo",
                "Nome"
                );

            ViewBag.ChkSkill = new SkillsObject().ListaSkills();

            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                //Verifica se esse usuario já está cadastrado
                if (model.ExisteUsuario(false))
                {
                    ModelState.AddModelError("", "Já existe usuário com este login");
                    return View(model);
                }
                else
                {
                    if (model.EditaUsuario())
                    {
                        return Redirect("/Gestao/Usuarios");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Erro ao editar usuários");
                        return View(model);
                    }
                }
            }
        }

        public ActionResult ExcluirUsuario(int id)
        {
            new Usuarios().ExcluirUsuario(id);
            return Redirect("/Gestao/Usuarios");
        }

        //Skills
        public ActionResult Skills()
        {
            SkillsObject s = new SkillsObject();
            var model = s.ListaSkills();
            return View(model);
        }

        public ActionResult NewSkill()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult NewSkill(Skill model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                //Verifica se essa skill ja esta cadastrada
                if (model.ExisteSkill()){
                    ModelState.AddModelError("", "Skill já existe");
                    return View(model);
                }
                else {
                    if (model.CriaSkill())
                    {
                        return Redirect("/Gestao/Skills");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Erro ao criar skill");
                        return View(model);
                    }
                }
            }
        }        

        public ActionResult EditSkill(int id)
        {
            var model = new Skill().GetSkill(id);
            return View(model);
        }

        [HttpPost]
        public ActionResult EditSkill(Skill model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            else
            {
                //Verifica se essa skill ja esta cadastrada
                if (model.ExisteSkill())
                {
                    ModelState.AddModelError("", "Skill já existe");
                    return View(model);
                }
                else
                {
                    if (model.EditaSkill())
                    {
                        return Redirect("/Gestao/Skills");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Erro ao editar skill");
                        return View(model);
                    }
                }
            }
        }

        public ActionResult ExcluirSkill(int id)
        {
            new Skill().ExcluirSkill(id);
            return Redirect("/Gestao/Skills");
        }
    }
}